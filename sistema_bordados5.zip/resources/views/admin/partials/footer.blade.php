<footer class="h-12 bg-white border-t flex items-center justify-center text-xs text-gray-500">
    © {{ date('Y') }} Sistema de Bordados · Panel Administrativo
</footer>
