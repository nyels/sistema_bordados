<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\MaterialVariant;
use Carbon\Carbon;

/**
 * HomeController - Dashboard Mínimo Correcto
 *
 * PRINCIPIO: Pocos números VERDADEROS > Muchos números FALSOS
 *
 * Este dashboard muestra SOLO métricas verificables:
 * - Conteos instantáneos (estado actual del sistema)
 * - Ventas por día (últimos 14 días, SIN acumulación)
 * - Top 5 productos (mes actual)
 */
class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // ========================================
        // BLOQUE A: OPERATIVO (Conteos Instantáneos)
        // ========================================
        // Estos son COUNT exactos del estado ACTUAL del sistema
        // No tienen ventana temporal - son "fotos" del momento

        // SQL: SELECT COUNT(*) FROM orders WHERE status = 'in_production'
        $ordersInProduction = Order::where('status', Order::STATUS_IN_PRODUCTION)->count();

        // SQL: SELECT COUNT(*) FROM orders WHERE status = 'ready'
        $ordersReady = Order::where('status', Order::STATUS_READY)->count();

        // SQL: SELECT COUNT(*) FROM orders WHERE status = 'confirmed'
        //      AND EXISTS (SELECT 1 FROM order_items WHERE has_pending_adjustments = true OR ...)
        $ordersBlocked = Order::where('status', Order::STATUS_CONFIRMED)
            ->whereHas('items', function ($q) {
                $q->where('has_pending_adjustments', true)
                    ->orWhere(function ($q2) {
                        $q2->where('personalization_type', 'design')
                            ->where('design_approved', false);
                    });
            })->count();

        // SQL: SELECT COUNT(*) FROM orders WHERE status = 'confirmed'
        $backlog = Order::where('status', Order::STATUS_CONFIRMED)->count();

        // SQL: SELECT COUNT(*) FROM orders
        //      WHERE status IN ('confirmed','in_production','ready')
        //      AND promised_date < CURDATE()
        $ordersDelayed = Order::whereIn('status', [
                Order::STATUS_CONFIRMED,
                Order::STATUS_IN_PRODUCTION,
                Order::STATUS_READY
            ])
            ->whereNotNull('promised_date')
            ->where('promised_date', '<', Carbon::today())
            ->count();

        // SQL: SELECT COUNT(*) FROM material_variants
        //      WHERE activo = 1 AND current_stock <= min_stock_alert
        $materialsLowStock = MaterialVariant::where('activo', true)
            ->whereColumn('current_stock', '<=', 'min_stock_alert')
            ->count();

        // ========================================
        // BLOQUE B: VENTAS POR DÍA (Últimos 14 días)
        // ========================================
        // Esta es la ÚNICA gráfica del dashboard
        // Reglas:
        // - Ventana temporal FIJA: 14 días
        // - groupBy DATE(created_at)
        // - SUM(total) por día
        // - SIN acumulación histórica

        $startDate = Carbon::now()->subDays(13)->startOfDay();
        $endDate = Carbon::now()->endOfDay();

        // SQL: SELECT DATE(created_at) as date, SUM(total) as total
        //      FROM orders
        //      WHERE status != 'cancelled'
        //      AND created_at BETWEEN '2026-01-08' AND '2026-01-21 23:59:59'
        //      GROUP BY DATE(created_at)
        //      ORDER BY date ASC
        $salesByDayRaw = Order::whereNotIn('status', [Order::STATUS_CANCELLED])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw('DATE(created_at) as date, SUM(total) as total')
            ->groupBy('date')
            ->orderBy('date')
            ->get()
            ->pluck('total', 'date')
            ->toArray();

        // Rellenar días sin ventas con 0 (para que la gráfica sea continua)
        $salesByDay = [];
        $currentDate = $startDate->copy();
        while ($currentDate <= $endDate) {
            $dateKey = $currentDate->format('Y-m-d');
            $salesByDay[$dateKey] = $salesByDayRaw[$dateKey] ?? 0;
            $currentDate->addDay();
        }

        // Total de los 14 días (para mostrar como referencia)
        $salesLast14Days = array_sum($salesByDay);

        // ========================================
        // BLOQUE C: TOP 5 PRODUCTOS (Mes Actual)
        // ========================================
        // Reglas:
        // - Ventana temporal: mes actual (1ro al día de hoy)
        // - groupBy product_id
        // - SUM(quantity)
        // - ORDER BY total_sold DESC
        // - LIMIT 5

        $monthStart = Carbon::now()->startOfMonth();
        $monthEnd = Carbon::now()->endOfDay();
        $monthName = Carbon::now()->translatedFormat('F Y');

        // SQL: SELECT product_name, SUM(quantity) as total_sold, SUM(total) as total_value
        //      FROM order_items
        //      JOIN orders ON order_items.order_id = orders.id
        //      WHERE orders.status != 'cancelled'
        //      AND order_items.created_at BETWEEN '2026-01-01' AND '2026-01-21 23:59:59'
        //      GROUP BY product_name
        //      ORDER BY total_sold DESC
        //      LIMIT 5
        $topProducts = OrderItem::whereBetween('order_items.created_at', [$monthStart, $monthEnd])
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->whereNotIn('orders.status', [Order::STATUS_CANCELLED])
            ->selectRaw('order_items.product_name, SUM(order_items.quantity) as total_sold, SUM(order_items.total) as total_value')
            ->groupBy('order_items.product_name')
            ->orderByDesc('total_sold')
            ->take(5)
            ->get();

        // Total ventas del mes (para mostrar como referencia)
        $salesThisMonth = Order::whereBetween('created_at', [$monthStart, $monthEnd])
            ->whereNotIn('status', [Order::STATUS_CANCELLED])
            ->sum('total');

        // ========================================
        // RETORNO - Solo variables necesarias
        // ========================================
        return view('home', compact(
            // Bloque A: Operativo
            'ordersInProduction',
            'ordersReady',
            'ordersBlocked',
            'backlog',
            'ordersDelayed',
            'materialsLowStock',
            // Bloque B: Gráfica
            'salesByDay',
            'salesLast14Days',
            // Bloque C: Top Productos
            'topProducts',
            'salesThisMonth',
            'monthName'
        ));
    }
}
