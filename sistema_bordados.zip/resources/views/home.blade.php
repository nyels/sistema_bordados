@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</h1>
        <small class="text-muted">{{ now()->format('d/m/Y H:i') }}</small>
    </div>
@stop

@section('content')
{{-- ============================================= --}}
{{-- BLOQUE A: ESTADO OPERATIVO --}}
{{-- ============================================= --}}
{{-- Conteos instantáneos del estado ACTUAL del sistema --}}
{{-- Cada número es un COUNT exacto, sin acumulaciones --}}

<div class="row">
    {{-- En Producción --}}
    <div class="col-lg-2 col-md-4 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3>{{ $ordersInProduction }}</h3>
                <p>En Producción</p>
            </div>
            <div class="icon"><i class="fas fa-cogs"></i></div>
            <a href="{{ route('admin.orders.index', ['status' => 'in_production']) }}" class="small-box-footer">
                Ver <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    {{-- Listos para Entregar --}}
    <div class="col-lg-2 col-md-4 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3>{{ $ordersReady }}</h3>
                <p>Listos</p>
            </div>
            <div class="icon"><i class="fas fa-box-open"></i></div>
            <a href="{{ route('admin.orders.index', ['status' => 'ready']) }}" class="small-box-footer">
                Ver <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    {{-- Backlog (Confirmados) --}}
    <div class="col-lg-2 col-md-4 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3>{{ $backlog }}</h3>
                <p>Backlog</p>
            </div>
            <div class="icon"><i class="fas fa-clipboard-list"></i></div>
            <a href="{{ route('admin.orders.index', ['status' => 'confirmed']) }}" class="small-box-footer">
                Ver <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    {{-- Bloqueados --}}
    <div class="col-lg-2 col-md-4 col-6">
        <div class="small-box {{ $ordersBlocked > 0 ? 'bg-danger' : 'bg-secondary' }}">
            <div class="inner">
                <h3>{{ $ordersBlocked }}</h3>
                <p>Bloqueados</p>
            </div>
            <div class="icon"><i class="fas fa-ban"></i></div>
            <a href="{{ route('admin.orders.index', ['status' => 'confirmed']) }}" class="small-box-footer">
                Resolver <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    {{-- Con Retraso --}}
    <div class="col-lg-2 col-md-4 col-6">
        <div class="small-box {{ $ordersDelayed > 0 ? 'bg-danger' : 'bg-secondary' }}">
            <div class="inner">
                <h3>{{ $ordersDelayed }}</h3>
                <p>Retrasados</p>
            </div>
            <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
            <a href="{{ route('admin.orders.index') }}" class="small-box-footer">
                Ver <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    {{-- Materiales Bajo Mínimo --}}
    <div class="col-lg-2 col-md-4 col-6">
        <div class="small-box {{ $materialsLowStock > 0 ? 'bg-danger' : 'bg-secondary' }}">
            <div class="inner">
                <h3>{{ $materialsLowStock }}</h3>
                <p>Stock Bajo</p>
            </div>
            <div class="icon"><i class="fas fa-boxes"></i></div>
            <a href="{{ route('admin.inventory.index') }}" class="small-box-footer">
                Ver <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
</div>

{{-- ============================================= --}}
{{-- BLOQUE B: VENTAS ÚLTIMOS 14 DÍAS --}}
{{-- ============================================= --}}
{{-- Una sola gráfica con ventana temporal fija --}}
{{-- groupBy DATE(created_at), SUM(total), sin acumulación --}}

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-chart-bar mr-2"></i>
                    Ventas por Día (Últimos 14 días)
                </h3>
                <div class="card-tools">
                    <span class="badge badge-success">
                        Total: ${{ number_format($salesLast14Days, 0) }}
                    </span>
                </div>
            </div>
            <div class="card-body">
                <canvas id="salesChart" style="height: 250px;"></canvas>
            </div>
            <div class="card-footer text-muted" style="font-size: 12px;">
                <i class="fas fa-info-circle mr-1"></i>
                Cada barra representa el total de ventas de pedidos creados ese día.
                No incluye pedidos cancelados.
            </div>
        </div>
    </div>

    {{-- ============================================= --}}
    {{-- BLOQUE C: TOP 5 PRODUCTOS DEL MES --}}
    {{-- ============================================= --}}
    {{-- groupBy product_name, SUM(quantity), ORDER DESC, LIMIT 5 --}}

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-trophy mr-2"></i>
                    Top 5 Productos - {{ $monthName }}
                </h3>
                <div class="card-tools">
                    <span class="badge badge-info">
                        ${{ number_format($salesThisMonth, 0) }}
                    </span>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-sm table-striped mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Producto</th>
                            <th class="text-right">Cant.</th>
                            <th class="text-right">Valor</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($topProducts as $index => $product)
                        <tr>
                            <td>
                                @if($index == 0)
                                    <i class="fas fa-medal text-warning"></i>
                                @elseif($index == 1)
                                    <i class="fas fa-medal text-secondary"></i>
                                @elseif($index == 2)
                                    <i class="fas fa-medal" style="color: #cd7f32;"></i>
                                @else
                                    {{ $index + 1 }}
                                @endif
                            </td>
                            <td>{{ Str::limit($product->product_name, 18) }}</td>
                            <td class="text-right">
                                <span class="badge badge-primary">{{ $product->total_sold }}</span>
                            </td>
                            <td class="text-right">${{ number_format($product->total_value, 0) }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted py-3">
                                Sin ventas este mes
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-muted" style="font-size: 12px;">
                <i class="fas fa-info-circle mr-1"></i>
                Productos vendidos del 1 al {{ now()->day }} de {{ now()->translatedFormat('F') }}.
            </div>
        </div>
    </div>
</div>

{{-- ============================================= --}}
{{-- ACCIONES RÁPIDAS --}}
{{-- ============================================= --}}

<div class="row">
    <div class="col-12">
        <div class="card card-outline card-dark">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-bolt mr-2"></i>Acciones Rápidas</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 col-6 mb-2">
                        <a href="{{ route('admin.orders.create') }}" class="btn btn-success btn-block">
                            <i class="fas fa-plus mr-1"></i> Nuevo Pedido
                        </a>
                    </div>
                    <div class="col-md-3 col-6 mb-2">
                        <a href="{{ route('admin.purchases.create') }}" class="btn btn-info btn-block">
                            <i class="fas fa-shopping-cart mr-1"></i> Nueva Compra
                        </a>
                    </div>
                    <div class="col-md-3 col-6 mb-2">
                        <a href="{{ route('admin.production.queue') }}" class="btn btn-warning btn-block">
                            <i class="fas fa-industry mr-1"></i> Cola Producción
                        </a>
                    </div>
                    <div class="col-md-3 col-6 mb-2">
                        <a href="{{ route('admin.orders.index') }}" class="btn btn-secondary btn-block">
                            <i class="fas fa-list mr-1"></i> Todos los Pedidos
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop

@section('css')
<style>
    .small-box .inner h3 {
        font-size: 2rem;
    }
    .small-box .inner p {
        font-size: 0.9rem;
    }
    .small-box .icon {
        font-size: 60px;
    }
</style>
@stop

@section('js')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips
    $('[data-toggle="tooltip"]').tooltip();

    // Datos de ventas por día
    const salesData = @json($salesByDay);
    const labels = Object.keys(salesData).map(d => {
        const date = new Date(d);
        return date.getDate() + '/' + (date.getMonth() + 1);
    });
    const values = Object.values(salesData);

    // Calcular el máximo para la escala
    const maxValue = Math.max(...values, 1);
    const suggestedMax = Math.ceil(maxValue * 1.1);

    // Gráfica de barras (no línea, para evitar confusión visual)
    new Chart(document.getElementById('salesChart'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Ventas ($)',
                data: values,
                backgroundColor: 'rgba(40, 167, 69, 0.7)',
                borderColor: 'rgb(40, 167, 69)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '$' + context.raw.toLocaleString('es-MX', {minimumFractionDigits: 2});
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    suggestedMax: suggestedMax,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
});
</script>
@stop
