@extends('adminlte::page')

@section('title', 'Pedidos')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1><i class="fas fa-clipboard-list mr-2"></i> Pedidos</h1>
        <div>
            <a href="{{ route('admin.orders.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nuevo Pedido
            </a>
        </div>
    </div>
@stop

@section('content')
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
    @endif

    @include('admin.orders._filters')

    <div class="card">
        <div class="card-body table-responsive p-0">
            <table class="table table-hover table-striped" style="font-size: 14px;">
                <thead class="bg-light">
                    <tr>
                        <th>Pedido</th>
                        <th>Cliente</th>
                        <th>Items</th>
                        <th class="text-right">Total</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center">Pago</th>
                        <th>Entrega</th>
                        <th class="text-center" data-toggle="tooltip" title="Indica si el pedido puede avanzar o tiene algo pendiente">Situación</th>
                        <th class="text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($orders as $order)
                        @php
                            $hasAdjustments = $order->hasPendingAdjustments();
                            $hasDesignPending = $order->hasItemsPendingDesignApproval();
                            $hasMeasurementsChanged = $order->items->contains(fn($i) => $i->hasMeasurementsChangedAfterApproval());
                            $hasBlockers = $hasAdjustments || $hasDesignPending || $hasMeasurementsChanged;
                            $isConfirmed = $order->status === \App\Models\Order::STATUS_CONFIRMED;
                        @endphp
                        <tr>
                            <td>
                                <a href="{{ route('admin.orders.show', $order) }}" class="font-weight-bold" style="font-size: 15px;">
                                    {{ $order->order_number }}
                                </a>
                                @if($order->isAnnex())
                                    <span class="badge badge-info ml-1" title="Pedido Anexo">
                                        <i class="fas fa-link"></i>
                                    </span>
                                @endif
                                @if($order->urgency_level !== 'normal')
                                    <span class="badge badge-{{ $order->urgency_color }} ml-1">
                                        {{ $order->urgency_label }}
                                    </span>
                                @endif
                            </td>
                            <td>{{ $order->cliente->nombre }} {{ $order->cliente->apellidos }}</td>
                            <td>{{ $order->items->count() }}</td>
                            <td class="text-right font-weight-bold" style="font-size: 16px;">${{ number_format($order->total, 2) }}</td>
                            <td class="text-center">
                                <span class="badge badge-{{ $order->status_color }}" style="font-size: 13px;">
                                    {{ $order->status_label }}
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-{{ $order->payment_status_color }}">
                                    {{ $order->payment_status_label }}
                                </span>
                            </td>
                            <td>
                                @if($order->promised_date)
                                    {{ $order->promised_date->format('d/m/Y') }}
                                @else
                                    <span class="text-muted">-</span>
                                @endif
                            </td>
                            <td class="text-center">
                                @if($isConfirmed && $hasBlockers)
                                    @php
                                        $blockerReasons = [];
                                        if($hasAdjustments) $blockerReasons[] = 'Ajuste de precio pendiente de aprobar';
                                        if($hasDesignPending) $blockerReasons[] = 'Diseño pendiente de aprobación';
                                        if($hasMeasurementsChanged) $blockerReasons[] = 'Medidas cambiaron después de aprobar diseño';
                                        $blockerText = implode("\n", $blockerReasons);
                                    @endphp
                                    <span class="text-danger" data-toggle="tooltip" data-placement="left"
                                          title="{{ $blockerText }}">
                                        <i class="fas fa-ban"></i>
                                        <small>Bloqueado</small>
                                    </span>
                                @elseif($isConfirmed && !$hasBlockers)
                                    <span class="text-success" data-toggle="tooltip" data-placement="left"
                                          title="Listo para iniciar producción. Todos los requisitos cumplidos.">
                                        <i class="fas fa-check-circle"></i>
                                        <small>Listo</small>
                                    </span>
                                @elseif($order->status === \App\Models\Order::STATUS_DRAFT)
                                    <span class="text-muted" data-toggle="tooltip" data-placement="left"
                                          title="Borrador: Falta confirmar pedido con el cliente">
                                        <i class="fas fa-edit"></i>
                                    </span>
                                @elseif($order->status === \App\Models\Order::STATUS_IN_PRODUCTION)
                                    <span class="text-warning" data-toggle="tooltip" data-placement="left"
                                          title="En producción: Materiales reservados, trabajo en curso">
                                        <i class="fas fa-cogs"></i>
                                    </span>
                                @elseif($order->status === \App\Models\Order::STATUS_READY)
                                    <span class="text-info" data-toggle="tooltip" data-placement="left"
                                          title="Listo para entregar: Avisar al cliente para recoger">
                                        <i class="fas fa-box-open"></i>
                                    </span>
                                @elseif($order->status === \App\Models\Order::STATUS_DELIVERED)
                                    <span class="text-success" data-toggle="tooltip" data-placement="left"
                                          title="Entregado: Pedido completado">
                                        <i class="fas fa-check-double"></i>
                                    </span>
                                @else
                                    <span class="text-muted">-</span>
                                @endif
                            </td>
                            <td class="text-right">
                                @if($order->status === \App\Models\Order::STATUS_DRAFT)
                                    <a href="{{ route('admin.orders.edit', $order) }}" class="btn btn-sm btn-warning" title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                @endif
                                <a href="{{ route('admin.orders.show', $order) }}" class="btn btn-sm btn-info" title="Ver">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" class="text-center py-4 text-muted">
                                No hay pedidos registrados.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($orders->hasPages())
            <div class="card-footer">
                {{ $orders->withQueryString()->links() }}
            </div>
        @endif
    </div>
@stop

@section('js')
<script>
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
@stop
