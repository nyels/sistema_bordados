{{--
    DEPRECATED: El controller edit() ahora usa create.blade.php con editMode=true
    Este archivo existe solo por compatibilidad.
--}}
