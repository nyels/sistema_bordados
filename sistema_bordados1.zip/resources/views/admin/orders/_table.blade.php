{{-- Partial: Tabla de pedidos (para AJAX) --}}
<div class="card mb-0">
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-striped mb-0" style="font-size: 15px;">
            <thead style="background: #343a40; color: white;">
                <tr>
                    <th style="color: white;">Pedido</th>
                    <th style="color: white;">Cliente</th>
                    <th style="color: white;">Items</th>
                    <th class="text-right" style="color: white;">Total</th>
                    <th class="text-center" style="color: white;">Estado</th>
                    <th class="text-center" style="color: white;">Pago</th>
                    <th style="color: white;">Entrega</th>
                    <th class="text-right" style="color: white;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @forelse($orders as $order)
                    @php
                        $isDelayed = $order->promised_date &&
                                     $order->promised_date->lt(now()->startOfDay()) &&
                                     !in_array($order->status, [\App\Models\Order::STATUS_DELIVERED, \App\Models\Order::STATUS_CANCELLED]);
                    @endphp
                    <tr class="{{ $isDelayed ? 'table-danger' : '' }}">
                        <td>
                            <a href="{{ route('admin.orders.show', $order) }}" class="font-weight-bold" style="font-size: 15px;">
                                {{ $order->order_number }}
                            </a>
                            @if($order->isAnnex())
                                <span class="badge badge-info ml-1">
                                    <i class="fas fa-link"></i>
                                </span>
                            @endif
                            @if($order->urgency_level !== 'normal')
                                <span class="badge badge-{{ $order->urgency_color }} ml-1">
                                    {{ $order->urgency_label }}
                                </span>
                            @endif
                        </td>
                        <td style="color: #212529;">{{ $order->cliente->nombre }} {{ $order->cliente->apellidos }}</td>
                        <td style="color: #212529;">{{ $order->items->count() }}</td>
                        <td class="text-right font-weight-bold" style="font-size: 16px;">${{ number_format($order->total, 2) }}</td>
                        <td class="text-center">
                            <span class="badge badge-{{ $order->status_color }}" style="font-size: 13px;">
                                {{ $order->status_label }}
                            </span>
                        </td>
                        <td class="text-center">
                            <span class="badge badge-{{ $order->payment_status_color }}">
                                {{ $order->payment_status_label }}
                            </span>
                        </td>
                        <td>
                            @if($order->promised_date)
                                @if($isDelayed)
                                    <span class="text-danger font-weight-bold">
                                        <i class="fas fa-exclamation-circle"></i>
                                        {{ $order->promised_date->format('d/m/Y') }}
                                    </span>
                                @else
                                    <span style="color: #212529;">{{ $order->promised_date->format('d/m/Y') }}</span>
                                @endif
                            @else
                                <span style="color: #495057;">—</span>
                            @endif
                        </td>
                        <td class="text-right text-nowrap">
                            @if($order->balance > 0 && $order->status !== \App\Models\Order::STATUS_CANCELLED)
                                <button type="button"
                                        class="btn btn-sm btn-success btn-quick-payment"
                                        data-order-id="{{ $order->id }}"
                                        data-order-number="{{ $order->order_number }}"
                                        data-balance="{{ $order->balance }}"
                                        title="Registrar Pago">
                                    <i class="fas fa-dollar-sign"></i>
                                </button>
                            @endif
                            @if($order->status === \App\Models\Order::STATUS_DRAFT)
                                <a href="{{ route('admin.orders.edit', $order) }}" class="btn btn-sm btn-warning" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                            @endif
                            <a href="{{ route('admin.orders.show', $order) }}" class="btn btn-sm btn-info" title="Ver">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center py-4" style="color: #495057; font-size: 15px;">
                            No hay pedidos que coincidan con los filtros.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($orders->hasPages())
        <div class="card-footer">
            {{ $orders->withQueryString()->links() }}
        </div>
    @endif
</div>
