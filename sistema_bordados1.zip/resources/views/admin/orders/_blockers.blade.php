@php
    $hasAdjustments = $order->hasPendingAdjustments();
    $hasDesignPending = $order->hasItemsPendingDesignApproval();
    $hasMeasurementsChanged = $order->items->contains(fn($i) => $i->hasMeasurementsChangedAfterApproval());
    $hasMissingTechnicalDesigns = $order->hasItemsMissingTechnicalDesigns();
    $hasBlockers = $hasAdjustments || $hasDesignPending || $hasMeasurementsChanged || $hasMissingTechnicalDesigns;
    $itemsWithDesign = $order->getItemsBlockingForDesign();
    $itemsWithMeasurements = $order->items->filter(fn($i) => $i->hasMeasurementsChangedAfterApproval());
    $itemsMissingTechnical = $order->getItemsMissingTechnicalDesigns();
@endphp

@if($hasBlockers)
    <div class="card border-danger mb-3">
        <div class="card-header bg-danger text-white py-2">
            <i class="fas fa-hand-paper mr-2"></i>
            <strong style="font-size: 16px;">Este pedido NO puede iniciar producción</strong>
        </div>
        <div class="card-body" style="font-size: 15px;">
            <p class="mb-3" style="color: #495057;">Resuelva los siguientes puntos antes de enviar a producción:</p>

            @if($hasAdjustments)
                <div class="d-flex align-items-start mb-3 p-3 bg-light rounded">
                    <span class="badge badge-danger mr-3 mt-1" style="font-size: 14px; padding: 8px 12px;">1</span>
                    <div>
                        <strong style="color: #c62828; font-size: 16px;">Ajuste de precio pendiente</strong>
                        <p class="mb-2" style="color: #495057; font-size: 14px;">
                            Hay cambios en el precio que el cliente debe aprobar antes de continuar.
                        </p>
                        <span style="color: #1565c0; font-size: 14px;">
                            <i class="fas fa-arrow-right mr-1"></i>
                            <strong>Acción:</strong> Contactar al cliente para aprobar el nuevo precio.
                        </span>
                    </div>
                </div>
            @endif

            @if($hasDesignPending)
                <div class="d-flex align-items-start mb-3 p-3 bg-light rounded">
                    <span class="badge badge-warning mr-3 mt-1" style="font-size: 14px; padding: 8px 12px;">{{ $hasAdjustments ? '2' : '1' }}</span>
                    <div>
                        <strong style="color: #e65100; font-size: 16px;">Diseño pendiente de aprobación</strong>
                        <p class="mb-2" style="color: #495057; font-size: 14px;">
                            El cliente debe aprobar el diseño de los siguientes productos:
                        </p>
                        <div class="mb-2">
                            @foreach($itemsWithDesign as $item)
                                <span class="badge mr-1" style="background: #6c757d; color: white; font-size: 14px; padding: 6px 10px;">{{ $item->product_name }}</span>
                            @endforeach
                        </div>
                        <span style="color: #1565c0; font-size: 14px;">
                            <i class="fas fa-arrow-right mr-1"></i>
                            <strong>Acción:</strong> Ir a la sección "Diseño/Personalización" más abajo para gestionar.
                        </span>
                    </div>
                </div>
            @endif

            @if($hasMeasurementsChanged)
                @php $stepNum = ($hasAdjustments ? 1 : 0) + ($hasDesignPending ? 1 : 0) + 1; @endphp
                <div class="d-flex align-items-start mb-3 p-3 bg-light rounded">
                    <span class="badge badge-info mr-3 mt-1" style="font-size: 14px; padding: 8px 12px;">{{ $stepNum }}</span>
                    <div>
                        <strong style="color: #0277bd; font-size: 16px;">Medidas modificadas después de aprobar diseño</strong>
                        <p class="mb-2" style="color: #495057; font-size: 14px;">
                            Las medidas del cliente cambiaron después de aprobar el diseño en:
                        </p>
                        <div class="mb-2">
                            @foreach($itemsWithMeasurements as $item)
                                <span class="badge mr-1" style="background: #6c757d; color: white; font-size: 14px; padding: 6px 10px;">{{ $item->product_name }}</span>
                            @endforeach
                        </div>
                        <span style="color: #1565c0; font-size: 14px;">
                            <i class="fas fa-arrow-right mr-1"></i>
                            <strong>Acción:</strong> El diseño debe re-aprobarse con las nuevas medidas.
                        </span>
                    </div>
                </div>
            @endif

            @if($hasMissingTechnicalDesigns)
                @php $stepNum = ($hasAdjustments ? 1 : 0) + ($hasDesignPending ? 1 : 0) + ($hasMeasurementsChanged ? 1 : 0) + 1; @endphp
                <div class="d-flex align-items-start mb-3 p-3 bg-light rounded">
                    <span class="badge mr-3 mt-1" style="font-size: 14px; padding: 8px 12px; background: #7b1fa2; color: white;">{{ $stepNum }}</span>
                    <div>
                        <strong style="color: #7b1fa2; font-size: 16px;">Sin diseño técnico vinculado</strong>
                        <p class="mb-2" style="color: #495057; font-size: 14px;">
                            Los siguientes productos personalizados requieren un diseño técnico de producción:
                        </p>
                        <div class="mb-2">
                            @foreach($itemsMissingTechnical as $item)
                                <span class="badge mr-1" style="background: #6c757d; color: white; font-size: 14px; padding: 6px 10px;">
                                    {{ $item->product_name }}
                                    @if($item->embroidery_text)
                                        <small>({{ $item->embroidery_text }})</small>
                                    @endif
                                </span>
                            @endforeach
                        </div>
                        <span style="color: #1565c0; font-size: 14px;">
                            <i class="fas fa-arrow-right mr-1"></i>
                            <strong>Acción:</strong> Vincule un diseño técnico aprobado a cada producto en la sección "Productos".
                        </span>
                    </div>
                </div>
            @endif
        </div>
    </div>
@else
    <div class="alert mb-3" style="background: #28a745; border: none; padding: 16px 20px;">
        <div class="d-flex align-items-center">
            <i class="fas fa-check-circle fa-2x mr-3" style="color: white;"></i>
            <div>
                <strong style="color: white; font-size: 17px;">Listo para producción</strong>
                <p class="mb-0" style="color: rgba(255,255,255,0.9); font-size: 15px;">
                    Todos los requisitos cumplidos. Puede enviar este pedido a producción desde la
                    <a href="{{ route('admin.production.queue') }}" style="color: white; text-decoration: underline; font-weight: 600;">Cola de Producción</a>.
                </p>
            </div>
        </div>
    </div>
@endif
